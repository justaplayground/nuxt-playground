<script setup lang="ts">
definePageMeta({
  middleware: 'feed',
})
</script>

<template>
  <div>
    <slot />
  </div>
</template>
