import type { Config } from 'automd'

const config: Config = {
  input: ['README.md', '**/*.md'],
}

export default config
