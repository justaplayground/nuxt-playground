<template>
  <div grid="~ cols-minmax-20rem" gap4 p8>
    <slot />
  </div>
</template>
