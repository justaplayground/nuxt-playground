export const BASE_URL = 'https://hacker-news.firebaseio.com/v0'
