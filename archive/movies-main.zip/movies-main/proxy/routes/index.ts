export default eventHandler(() => {
  return 'Nuxt Movies Proxy: <a href="https://github.com/nuxt/movies/tree/main/proxy">Learn more</a>'
})
