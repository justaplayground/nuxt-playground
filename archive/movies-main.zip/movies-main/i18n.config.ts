export default defineI18nConfig(() => {
  return {
    fallbackLocale: 'en',
  }
})
