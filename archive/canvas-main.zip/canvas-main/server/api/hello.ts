export default defineEventHandler(() => {
  return 'Hello World!'
})
