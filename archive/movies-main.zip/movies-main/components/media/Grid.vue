<template>
  <div grid="~ cols-minmax-10rem lg:cols-minmax-15rem" gap4 p8>
    <slot />
  </div>
</template>
