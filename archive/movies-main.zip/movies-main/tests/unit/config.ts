const config = useRuntimeConfig()

export const baseUrl = config.public.apiBaseUrl
