export default defineEventHandler(() => 'Nuxt Movies API')
