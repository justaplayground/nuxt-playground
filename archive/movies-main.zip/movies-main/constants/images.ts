export const YOUTUBE_THUMBNAIL_QUALITY_NAME = 'maxresdefault.jpg'

export const TMDB_IMAGE_BASE_THUMBNAIL = 'https://image.tmdb.org/t/p/original'
export const TMDB_IMAGE_BASE_ORIGINAL = 'https://image.tmdb.org/t/p/original'
